import os
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table
from reportlab.lib.styles import getSampleStyleSheet
from docx import Document
import pandas as pd

def text_to_pdf(input_file, output_file):
    """Convert a text file to PDF."""
    pdf = SimpleDocTemplate(output_file, pagesize=letter)
    styles = getSampleStyleSheet()
    story = []

    with open(input_file, 'r', encoding='utf-8') as f:
        text = f.read()
    
    # Split text into paragraphs by newlines
    paragraphs = text.split('\n')
    for para in paragraphs:
        if para.strip():
            story.append(Paragraph(para, styles['Normal']))
            story.append(Spacer(1, 12))
    
    pdf.build(story)
    print(f"Converted {input_file} to {output_file}")

def docx_to_pdf(input_file, output_file):
    """Convert a .doc or .docx file to PDF."""
    pdf = SimpleDocTemplate(output_file, pagesize=letter)
    styles = getSampleStyleSheet()
    story = []

    doc = Document(input_file)
    for para in doc.paragraphs:
        if para.text.strip():
            story.append(Paragraph(para.text, styles['Normal']))
            story.append(Spacer(1, 12))
    
    pdf.build(story)
    print(f"Converted {input_file} to {output_file}")

def csv_to_pdf(input_file, output_file):
    """Convert a CSV file to PDF."""
    pdf = SimpleDocTemplate(output_file, pagesize=letter)
    styles = getSampleStyleSheet()
    story = []

    # Read CSV file
    df = pd.read_csv(input_file)
    
    # Convert DataFrame to a list of lists for the table
    data = [df.columns.tolist()] + df.values.tolist()
    
    # Create a table
    table = Table(data)
    table.setStyle([
        ('GRID', (0, 0), (-1, -1), 1, 'black'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, -1), 10),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
    ])
    
    story.append(table)
    pdf.build(story)
    print(f"Converted {input_file} to {output_file}")

def convert_to_pdf(input_file, output_dir="output"):
    """Main function to convert input file to PDF based on extension."""
    # Ensure output directory exists
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    
    # Get file extension
    file_ext = os.path.splitext(input_file)[1].lower()
    output_file = os.path.join(output_dir, os.path.splitext(os.path.basename(input_file))[0] + '.pdf')
    
    # Convert based on file extension
    try:
        if file_ext == '.txt':
            text_to_pdf(input_file, output_file)
        elif file_ext in ['.doc', '.docx']:
            docx_to_pdf(input_file, output_file)
        elif file_ext == '.csv':
            csv_to_pdf(input_file, output_file)
        else:
            print(f"Unsupported file format: {file_ext}")
    except Exception as e:
        print(f"Error converting {input_file}: {str(e)}")

if __name__ == "__main__":
    # Example usage
    input_files = ['CVADAS-0001-00000000-000.docx']
    for file in input_files:
        if os.path.exists(file):
            convert_to_pdf(file)
        else:
            print(f"File {file} does not exist")