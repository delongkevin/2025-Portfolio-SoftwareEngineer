import xml.etree.ElementTree as ET
from lxml import etree
import os

def create_odx_base_structure():
    """Create the basic ODX XML structure."""
    odx = ET.Element("ODX", VERSION="2.2.0", xmlns="http://www.asam.net/mcd/2.2/ODX")
    diag_layer_container = ET.SubElement(odx, "DIAG-LAYER-CONTAINER")
    diag_layer_container.set("SHORT-NAME", "DLC")
    ecu_variant = ET.SubElement(diag_layer_container, "ECU-VARIANT")
    ecu_variant.set("SHORT-NAME", "ECU1")
    diag_data_dictionary = ET.SubElement(ecu_variant, "DIAG-DATA-DICTIONARY-SPEC")
    return odx, diag_data_dictionary

def parse_cdd_file(cdd_file_path):
    """Parse the CDD file and extract diagnostic data."""
    try:
        tree = ET.parse(cdd_file_path)
        root = tree.getroot()
        dtcs = []
        services = []
        enums = []  # To capture ENUMDEF as potential DTCs or service IDs

        # Extract ENUMDEF (potential DTC codes or service IDs)
        for enum in root.findall(".//ENUMDEF"):
            enum_info = {
                "id": enum.get("id"),
                "name": enum.get("oid") or "UnknownEnum",
                "description": enum.findtext(".//COMMONSTRING") or ""
            }
            enums.append(enum_info)

        # Placeholder for DTCs and Services (adjust XPath based on full CDD structure)
        for dtc in root.findall(".//DTC"):  # Update if DTCs are under a different tag
            dtc_info = {
                "code": dtc.get("code"),
                "name": dtc.get("name"),
                "description": dtc.findtext("Description") or ""
            }
            dtcs.append(dtc_info)

        for service in root.findall(".//Service"):  # Update if Services are under a different tag
            service_info = {
                "id": service.get("id"),
                "name": service.get("name"),
                "request": service.findtext("Request") or "",
                "response": service.findtext("Response") or ""
            }
            services.append(service_info)

        # Use enums as DTCs if no DTCs found (temporary workaround)
        if not dtcs and enums:
            dtcs = [{"code": e["id"], "name": e["name"], "description": e["description"]} for e in enums]

        return dtcs, services
    except ET.ParseError as e:
        print(f"Error parsing CDD file: {e}")
        return [], []

def convert_to_odx(cdd_file_path, odx_file_path):
    """Convert CDD file to ODX format."""
    # Create ODX base structure
    odx, diag_data_dictionary = create_odx_base_structure()

    # Parse CDD file
    dtcs, services = parse_cdd_file(cdd_file_path)

    # Add DTCs to ODX
    dtc_spec = ET.SubElement(diag_data_dictionary, "DTC-SPEC")
    for dtc in dtcs:
        dtc_elem = ET.SubElement(dtc_spec, "DTC")
        dtc_elem.set("SHORT-NAME", dtc["name"])
        ET.SubElement(dtc_elem, "DTC-CODE").text = dtc["code"]
        ET.SubElement(dtc_elem, "DESCRIPTION").text = dtc["description"]

    # Add Services to ODX
    service_spec = ET.SubElement(diag_data_dictionary, "DIAG-COMM-SPEC")
    for service in services:
        service_elem = ET.SubElement(service_spec, "DIAG-COMM")
        service_elem.set("SHORT-NAME", service["name"])
        ET.SubElement(service_elem, "SERVICE-ID").text = service["id"]
        ET.SubElement(service_elem, "REQUEST").text = service["request"]
        ET.SubElement(service_elem, "POS-RESPONSE").text = service["response"]

    # Write ODX file
    tree = ET.ElementTree(odx)
    tree.write(odx_file_path, encoding="UTF-8", xml_declaration=True)
    print(f"ODX file generated: {odx_file_path}")

    # Optional: Validate ODX against schema (if schema file is available)
    try:
        with open("odx_schema.xsd", "rb") as schema_file:  # Provide ODX schema file
            schema = etree.XMLSchema(etree.parse(schema_file))
            odx_doc = etree.parse(odx_file_path)
            schema.assertValid(odx_doc)
            print("ODX file is valid against the schema.")
    except FileNotFoundError:
        print("ODX schema file not found. Skipping validation.")
    except etree.DocumentInvalid as e:
        print(f"ODX validation error: {e}")

def main():
    cdd_file = "CVADAS-0001-00000000-000.cdd"  # Updated to match your file
    odx_file = "CVADAS-0001-00000000-000.odx"  # Match the output file name
    if not os.path.exists(cdd_file):
        print(f"CDD file not found: {cdd_file}")
        return
    convert_to_odx(cdd_file, odx_file)

if __name__ == "__main__":
    main()