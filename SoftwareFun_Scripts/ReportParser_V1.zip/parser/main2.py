import sys
import os
import csv

def text_input(input="07.00_Sanity_FFT.html", keyword=
               "Magna_Software_Version/Planned_Release"):
  found_items = []
  with open(input, "r") as file:
    writeline = False
    for line in file:
      if keyword in line and "div" not in line:
        writeline = True
      if "<tr>" in line and writeline:
        found_items.append('newline')
        writeline = False
      if writeline:
        found_items.append(get_line_value(line))
  return found_items

def did_input(input="parser/Report_BEV_7_23.html", keyword="F181"):
  table = []
  found_key = False
  start_write = False
  with open(input, "r") as file:
    row = []
    for line in file:
      if "tr" in line and start_write:
        if row != []:
          table.append(row)
        row = []
       # table.append("\n")
      if "_22" + keyword in line:
        found_key = True
      if found_key and "Symbol" in line:
        start_write = True
      if "Completion of" in line:
        start_write = False
        found_key = False
      if start_write:
        value = get_line_value(line)
        if value != "":
          row.append(value)

  return table

def grab_heading(input="parser/Report_BEV_7_23.html", keyword="Statistics"):
  table = []
  start_write = False
  with open(input, "r") as file:
    row = []
    for line in file:
      if "tr" in line and start_write and row != []:
        table.append(row)
        row = []
      if keyword in line and "Heading" in line:
        start_write = True
      if "/table" in line:
        start_write = False
      if start_write:
        value = get_line_value(line)
        if value != "":
          row.append(value)

  return table

def text_output(output = "out.txt",found_items = []):
  with open(output, 'w') as file:
    for items in found_items:
      if items != "":
        file.write(items+", ")

def csv_output(output = "out.csv", tables = []):
  with open(output, 'w') as file:
    for table in tables:
      writer = csv.writer(file)
      writer.writerows(table)

def get_line_value(input=""):
  value = ""
  append = False
  for ch in input:
    if ch == "<":
      append = False
    if append:
      value += ch
    if ch == ">":
      append = True
  return value[:-1]


def main(arg):
  #html = input("html file name: ")
  #while not os.path.exists(html):
  #  html = input("file path not found. Try again: ")
  #keyword = input("keyword: ")
  #found_items = did_input(html,keyword)
  html = arg[1]
  keyword = arg[2]
  found_items = did_input(html,keyword)
  statistics = grab_heading(html, "Statistics")
  all_tables = [statistics, found_items]
  print(found_items)
  #text_output(output=html[:-5]+"_"+keyword+".txt", found_items=found_items)
  csv_output(output=html[:-5]+"_"+keyword+".csv", tables=all_tables)
  print("done")
  pass

if __name__ == '__main__':
  if len(sys.argv) > 2:
    main(sys.argv)
  else:
      print("No arg")


